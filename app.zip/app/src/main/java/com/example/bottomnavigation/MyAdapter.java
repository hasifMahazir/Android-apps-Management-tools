package com.example.bottomnavigation;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder>{
    private Context context;
    private ArrayList taskName_id, taskDueDate_id;

    public MyAdapter(Context context, ArrayList taskName_id, ArrayList taskDueDate_id) {
        this.context = context;
        this.taskName_id = taskName_id;
        this.taskDueDate_id = taskDueDate_id;

    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item,parent,false);
        return new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        holder.taskName_id.setText(String.valueOf(taskName_id.get(position)));
        holder.taskDueDate_id.setText(String.valueOf(taskDueDate_id.get(position)));
        holder.mainLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            Intent intent = new Intent(context,UpdateTask.class);
            intent.putExtra("name",String.valueOf(taskName_id.get(position)));
                intent.putExtra("dueDate",String.valueOf(taskDueDate_id.get(position)));

            context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return taskName_id.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView taskName_id,taskDueDate_id;
        LinearLayout mainLayout;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            taskName_id=itemView.findViewById(R.id.taskName);
            taskDueDate_id=itemView.findViewById(R.id.taskDueDate);
            mainLayout = itemView.findViewById(R.id.mainLayout);

        }
    }
}
