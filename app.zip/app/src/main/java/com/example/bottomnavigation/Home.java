package com.example.bottomnavigation;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;


public class Home extends AppCompatActivity {
    String userEmail;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);


        ImageButton insertButton = findViewById(R.id.insertHomebtn);
        ImageButton homeButton = findViewById(R.id.homebtn);

        insertButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start MainActivity1
                if (getIntent().hasExtra("user_email")) {
                    userEmail = getIntent().getStringExtra("user_email");
                } else {

                }
                Intent intent = new Intent(Home.this, MainActivity1.class);
                intent.putExtra("user_email",  userEmail);
                startActivity(intent);
            }
        });

        homeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start Userlist
                if (getIntent().hasExtra("user_email")) {
                    userEmail = getIntent().getStringExtra("user_email");
                } else {

                }
                Intent intent = new Intent(Home.this, Userlist.class);
                intent.putExtra("user_email",  userEmail);
                startActivity(intent);
            }
        });
    }
}

