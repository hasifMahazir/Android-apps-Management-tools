package com.example.bottomnavigation;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class UpdateTask extends AppCompatActivity {
    EditText name_input, dueDate_input;
    Button update_button, delete_button;
    String name, dueDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_task);

        name_input = findViewById(R.id.taskName1);
        dueDate_input = findViewById(R.id.taskDueDate1);
        update_button = findViewById(R.id.btnUpdate);
        delete_button = findViewById(R.id.btnDelete); // Initialize delete_button here

        getAndSetIntentData();

        ActionBar ab = getSupportActionBar();
        if (ab != null) {
            ab.setTitle(name);
        }

        update_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get updated values from EditText
                String updatedName = name_input.getText().toString();
                String updatedDueDate = dueDate_input.getText().toString();

                // Update data in the database
                DatabaseHelper dbHelper = new DatabaseHelper(UpdateTask.this);
                dbHelper.updateTask(name, dueDate, updatedName, updatedDueDate);

                // Show a toast message indicating the update
                Toast.makeText(UpdateTask.this, "Task Updated", Toast.LENGTH_SHORT).show();

                // Finish the activity
                finish();
            }
        });

        delete_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Delete data in the database
                DatabaseHelper dbHelper = new DatabaseHelper(UpdateTask.this);
                dbHelper.deleteOneRow(name, UpdateTask.this);

                // Show a toast message indicating the deletion
                Toast.makeText(UpdateTask.this, "Task Deleted", Toast.LENGTH_SHORT).show();

                // Finish the activity
                finish();
            }
        });

    }

    void getAndSetIntentData() {
        if (getIntent().hasExtra("name") && getIntent().hasExtra("dueDate")) {
            // getting from intent
            name = getIntent().getStringExtra("name");
            dueDate = getIntent().getStringExtra("dueDate");
            // Setting intent data
            name_input.setText(name);
            dueDate_input.setText(dueDate);
        } else {
            Toast.makeText(this, "No Data Appeared", Toast.LENGTH_SHORT).show();
        }
    }
}
