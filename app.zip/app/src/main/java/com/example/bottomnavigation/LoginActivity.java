package com.example.bottomnavigation;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.bottomnavigation.databinding.ActivityLoginBinding;

public class LoginActivity extends AppCompatActivity {

    private ActivityLoginBinding binding;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        databaseHelper = new DatabaseHelper(this);

        binding.loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    String email = binding.loginEmail.getText().toString();
                    String password = binding.loginPassword.getText().toString();

                    if (email.isEmpty() || password.isEmpty()) {
                        showToast("All fields are mandatory");
                    } else {
                        Boolean checkCredentials = databaseHelper.checkEmailPassword(email, password);

                        if (checkCredentials) {
                            showToast("Login Successfully!");

                            // Save user email to SharedPreferences
                            saveUserEmailToPreferences(email);

                            // Start Home activity
                            startHomeActivity(email);

                            // Finish the LoginActivity
                            finish();
                        } else {
                            showToast("Invalid Credentials");
                        }
                    }
                } catch (Exception e) {
                    handleException(e);
                }
            }
        });

        binding.signupRedirectText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    startSignupActivity();
                } catch (Exception e) {
                    handleException(e);
                }
            }
        });
    }

    private void showToast(String message) {
        Toast.makeText(LoginActivity.this, message, Toast.LENGTH_SHORT).show();
    }

    private void saveUserEmailToPreferences(String email) {
        SharedPreferences preferences = getSharedPreferences("user_prefs", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("user_email", email);
        editor.apply();
    }

    private void startHomeActivity(String email) {
        Intent intent = new Intent(LoginActivity.this, Home.class);
        intent.putExtra("user_email", email);
        startActivity(intent);
    }

    private void startSignupActivity() {
        Intent intent = new Intent(LoginActivity.this, SignupActivity.class);
        startActivity(intent);
    }

    private void handleException(Exception e) {
        e.printStackTrace();
        showToast("An error occurred");
    }
}
