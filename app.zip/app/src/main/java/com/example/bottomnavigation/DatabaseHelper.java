package com.example.bottomnavigation;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

import org.jetbrains.annotations.Nullable;

public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String databaseName = "SignLog.db";

    DatabaseHelper(@Nullable Context context) {
        super(context, "Data3.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase MyDatabase) {
        MyDatabase.execSQL("create Table users(email TEXT primary key, password TEXT)");
        MyDatabase.execSQL("create Table tasks(email TEXT , taskName TEXT, taskDueDate TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase MyDB, int i, int i1) {
        MyDB.execSQL("drop Table if exists users");
        MyDB.execSQL("drop Table if exists tasks");
        onCreate(MyDB);
    }

    public Boolean insertData(String email, String password) {
        SQLiteDatabase MyDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("email", email);
        contentValues.put("password", password);
        long result = MyDatabase.insert("users", null, contentValues);

        return result != -1;
    }

    public Boolean checkEmail(String email) {
        SQLiteDatabase MyDatabase = this.getWritableDatabase();
        Cursor cursor = MyDatabase.rawQuery("Select * from users where email = ?", new String[]{email});

        return cursor.getCount() > 0;
    }

    public Boolean checkEmailPassword(String email, String password) {
        SQLiteDatabase MyDatabase = this.getWritableDatabase();
        Cursor cursor = MyDatabase.rawQuery("Select * from users where email = ? and password = ?", new String[]{email, password});

        return cursor.getCount() > 0;
    }
//task
    public Boolean insertuserdata(String userEmails, String taskName, String taskDueDate) {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("email", userEmails); // Assuming 'email' is the column name for user emails
        contentValues.put("taskName", taskName);
        contentValues.put("taskDueDate", taskDueDate);

        long result = DB.insert("tasks", null, contentValues);
        if (result == -1) {
            // Insertion failed
            Log.e("DBHelper", "Insertion failed. TaskName: " + taskName + ", TaskDueDate: " + taskDueDate + ", emails: " + userEmails);
            return false;
        } else {
            // Insertion successful
            Log.d("DBHelper", "Insertion successful. TaskName: " + taskName + ", TaskDueDate: " + taskDueDate + ", emails: " + userEmails);
            return true;
        }
    }

    public Cursor getTasksByEmail(String userEmail) {
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("SELECT * FROM tasks WHERE email = ?", new String[]{userEmail});
        return cursor;
    }

    void updateTask(String oldName, String oldDueDate, String newName, String newDueDate) {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("taskName", newName);
        cv.put("taskDueDate", newDueDate);

        String whereClause = "taskName = ? AND taskDueDate = ?";
        String[] whereArgs = {oldName, oldDueDate};

        int result = DB.update("tasks", cv, whereClause, whereArgs);

        if (result > 0) {
            // Update successful
            Log.d("DBHelper", "Update successful. OldName: " + oldName + ", OldDueDate: " + oldDueDate +
                    ", NewName: " + newName + ", NewDueDate: " + newDueDate);
        } else {
            // Update failed
            Log.e("DBHelper", "Update failed. OldName: " + oldName + ", OldDueDate: " + oldDueDate +
                    ", NewName: " + newName + ", NewDueDate: " + newDueDate);
        }
    }

    void deleteOneRow(String row_name, Context context) {
        SQLiteDatabase DB = this.getWritableDatabase();
        String whereClause = "taskName = ?";
        String[] whereArgs = {row_name};
        long result = DB.delete("tasks", whereClause, whereArgs);

        if (result == -1) {
            Toast.makeText(context, "Failed To Delete", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Successfully deleted", Toast.LENGTH_SHORT).show();
        }
    }

}
