package com.example.bottomnavigation;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.Toast;

import java.util.ArrayList;

public class Userlist extends AppCompatActivity {
    RecyclerView recyclerView;
    ArrayList taskName, taskDueDate;
    DatabaseHelper DB;
    MyAdapter adapter;
    String userEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_userlist);
        DB = new DatabaseHelper(this);
        taskName = new ArrayList<>();
        taskDueDate = new ArrayList<>();
        recyclerView = findViewById(R.id.recycleview);
        adapter = new MyAdapter(this,taskName,taskDueDate);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        displaydata();
    }


    private void displaydata(){
        if (getIntent().hasExtra("user_email")) {
            userEmail = getIntent().getStringExtra("user_email");
        } else {
            Toast.makeText(Userlist.this, "No entry exist", Toast.LENGTH_SHORT).show();
        }
        Cursor cursor = DB.getTasksByEmail(userEmail);
        if (cursor.getCount() == 0) {
            Toast.makeText(Userlist.this, "No entry exist", Toast.LENGTH_SHORT).show();
        } else {
            while (cursor.moveToNext()) {
                taskName.add(cursor.getString(1));
                taskDueDate.add(cursor.getString(2));
            }
        }
        adapter.notifyDataSetChanged(); // Notify adapter after updating data
    }
}