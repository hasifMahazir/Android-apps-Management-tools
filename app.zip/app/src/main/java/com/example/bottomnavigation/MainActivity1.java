package com.example.bottomnavigation;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity1 extends AppCompatActivity {
    EditText textTaskName, textTaskDueDate;
    Button insert, view;
    DatabaseHelper DB;
    String user_emails;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main1);
        Intent intent = getIntent();

        if (intent.hasExtra("user_email")) {
            user_emails = intent.getStringExtra("user_email");
        } else {
            // Handle the case where user_email extra is missing
            // (For example, re-route to login or handle accordingly)
            // Finish activity or prompt user to login again
        }
        textTaskName = findViewById(R.id.taskName);
        textTaskDueDate = findViewById(R.id.taskDueDate);

        insert = findViewById(R.id.btnInsert);
        view = findViewById(R.id.btnView);

        DB = new DatabaseHelper(this);
        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity1.this,Userlist.class);
                intent.putExtra("user_email", user_emails);
                startActivity(intent);
            }
        });

        insert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String taskNameTXT = textTaskName.getText().toString();
                String taskDueDateTXT = textTaskDueDate.getText().toString();

                Boolean checkInsertData = DB.insertuserdata(user_emails, taskNameTXT, taskDueDateTXT);
                if (checkInsertData) {
                    Toast.makeText(MainActivity1.this, "New Entry Inserted", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(MainActivity1.this, "Failed", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}